#!/data/data/com.termux/files/usr/bin/bash


_dl_completion(){

    local commands="
    doctor
    version
    update
    history
    stats
    clean
    config
    language
    theme
    help
    "

    COMPREPLY=( $(compgen -W "$commands" "${COMP_WORDS[1]}") )

}


complete -F _dl_completion dl
