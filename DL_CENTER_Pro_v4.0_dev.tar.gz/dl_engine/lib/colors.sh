#!/data/data/com.termux/files/usr/bin/bash


RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[34m"
CYAN="\033[36m"
WHITE="\033[37m"
RESET="\033[0m"


function success(){
echo -e "${GREEN}$1${RESET}"
}


function error(){
echo -e "${RED}$1${RESET}"
}


function info(){
echo -e "${CYAN}$1${RESET}"
}
