#!/data/data/com.termux/files/usr/bin/bash


source "$DL_HOME/lib/animation.sh"



clear


echo "================================="
echo
echo "        DL CENTER Pro v4.0"
echo
echo "================================="


loading "Initializing"
