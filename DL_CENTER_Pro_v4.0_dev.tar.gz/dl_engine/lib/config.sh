#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Configuration Manager
# Author : DL CENTER
# ==========================================

CONFIG_FILE="$DL_CONFIG/config.conf"

############################################
# 配置文件是否存在
############################################

config_exists() {

    [ -f "$CONFIG_FILE" ]

}

############################################
# 加载配置
############################################

config_load() {

    if ! config_exists; then

        echo "[ERROR] Config file not found."

        return 1

    fi

    while IFS='=' read -r key value

    do

        [[ "$key" =~ ^#.*$ ]] && continue
        [ -z "$key" ] && continue

        export "$key=$value"

    done < "$CONFIG_FILE"

}

############################################
# 获取配置
############################################

dl_config_get() {

    local key="$1"

    eval echo \$$key

}

############################################
# 修改配置
############################################

dl_config_set() {

    local key="$1"
    local value="$2"

    if grep -q "^${key}=" "$CONFIG_FILE"; then

        sed -i "s#^${key}=.*#${key}=${value}#g" "$CONFIG_FILE"

    else

        echo "${key}=${value}" >> "$CONFIG_FILE"

    fi

}

############################################
# 删除配置
############################################

dl_config_remove() {

    local key="$1"

    sed -i "/^${key}=/d" "$CONFIG_FILE"

}

############################################
# 重载配置
############################################

config_reload() {

    config_load

}

############################################
# 打印所有配置
############################################

config_list() {

    cat "$CONFIG_FILE"

}
