#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Module : Logger System
# Version: 2.1.0
# ==========================================


LOG_DIR="$DL_HOME/logs"

DOWNLOAD_LOG="$LOG_DIR/download.log"
SYSTEM_LOG="$LOG_DIR/system.log"
ERROR_LOG="$LOG_DIR/error.log"
HISTORY_LOG="$LOG_DIR/history.log"


############################################
# 初始化日志目录
############################################

logger_init()
{

    mkdir -p "$LOG_DIR"

}



############################################
# 时间
############################################

logger_time()
{

    date "+%F %T"

}



############################################
# 普通系统日志
############################################

logger_info()
{

    MSG="$1"

    echo "[$(logger_time)][INFO] $MSG" \
    | tee -a "$SYSTEM_LOG"

}



############################################
# 成功
############################################

logger_success()
{

    MSG="$1"

    echo "[$(logger_time)][SUCCESS] $MSG" \
    | tee -a "$SYSTEM_LOG"

}



############################################
# 警告
############################################

logger_warn()
{

    MSG="$1"

    echo "[$(logger_time)][WARN] $MSG" \
    | tee -a "$SYSTEM_LOG"

}



############################################
# 错误
############################################

logger_error()
{

    MSG="$1"

    echo "[$(logger_time)][ERROR] $MSG" \
    | tee -a "$ERROR_LOG"

}



############################################
# 调试
############################################

logger_debug()
{

    MSG="$1"

    echo "[$(logger_time)][DEBUG] $MSG" \
    >> "$SYSTEM_LOG"

}



############################################
# 下载日志
############################################

logger_download()
{

    MSG="$1"

    echo "[$(logger_time)][DOWNLOAD] $MSG" \
    >> "$DOWNLOAD_LOG"

}



############################################
# 初始化
############################################

logger_init
