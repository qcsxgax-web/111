#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Module : Core Utilities
# Version: 1.0.0
# ==========================================

# 文件是否存在
core_file_exists() {
    [ -f "$1" ]
}

# 目录是否存在
core_dir_exists() {
    [ -d "$1" ]
}

# 创建目录
core_mkdir() {
    [ -z "$1" ] && return 1
    mkdir -p "$1"
}

# 删除目录
core_rmdir() {
    [ -d "$1" ] && rm -rf "$1"
}

# 命令是否存在
core_command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# 获取时间
core_now() {
    date "+%Y-%m-%d %H:%M:%S"
}

# 获取版本
core_version() {
    grep "^VERSION=" "$DL_CONFIG/version.conf" | cut -d= -f2
}

# 获取 Build
core_build() {
    grep "^BUILD=" "$DL_CONFIG/version.conf" | cut -d= -f2
}

# 获取 Codename
core_codename() {
    grep "^CODENAME=" "$DL_CONFIG/version.conf" | cut -d= -f2
}

# 是否首次运行
core_is_first_run() {
    grep "^FIRST_RUN=true" "$DL_CONFIG/config.conf" >/dev/null 2>&1
}

# 检查 Root
core_check_storage() {
    [ -d "/sdcard/Download/Termux" ]
}

# 输出横线
core_line() {
    printf '%*s\n' "${COLUMNS:-60}" '' | tr ' ' '-'
}

# 暂停
core_pause() {
    printf "Press Enter to continue..."
    read -r
}
