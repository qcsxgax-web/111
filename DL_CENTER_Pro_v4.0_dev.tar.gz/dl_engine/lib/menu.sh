#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Unified Interactive Menu Engine
# ==========================================

MENU_SELECTED=0
MENU_INPUT=""

# ------------------------------------------
# 清屏
# ------------------------------------------

menu_clear()
{
    clear
}

# ------------------------------------------
# 暂停
# ------------------------------------------

menu_pause()
{
    echo ""
    read -r -p "按 Enter 键继续..."
}

# ------------------------------------------
# 读取按键
# ------------------------------------------

menu_read_key()
{
    local key
    local seq

    IFS= read -rsn1 key

    # Enter
    if [ -z "$key" ]; then
        printf '%s\n' "ENTER"
        return
    fi

    # ESC / 方向键
    if [ "$key" = $'\x1b' ]; then

        IFS= read -rsn2 seq

        case "$seq" in
            "[A")
                printf '%s\n' "UP"
                ;;
            "[B")
                printf '%s\n' "DOWN"
                ;;
            "[C")
                printf '%s\n' "RIGHT"
                ;;
            "[D")
                printf '%s\n' "LEFT"
                ;;
            *)
                printf '%s\n' "ESC"
                ;;
        esac

        return
    fi

    # 数字
    case "$key" in
        [0-9])
            printf 'NUMBER:%s\n' "$key"
            return
            ;;
    esac

    # 退出
    case "$key" in
        q|Q)
            printf '%s\n' "QUIT"
            return
            ;;
    esac

    printf 'CHAR:%s\n' "$key"
}

# ------------------------------------------
# 菜单选择
#
# 返回：
#   0 = 正常选择
#   MENU_SELECTED = 选择编号
#
# 特殊：
#   MENU_SELECTED=0 = 退出
# ------------------------------------------

menu_select()
{
    local TITLE="$1"
    shift

    local ITEMS=("$@")
    local COUNT="${#ITEMS[@]}"

    [ "$COUNT" -gt 0 ] || return 1

    local SELECTED=0
    local KEY
    local NUMBER
    local i

    while true
    do
        menu_clear

        echo "================================="
        echo "        DL CENTER Pro"
        echo "================================="
        echo ""
        echo "$TITLE"
        echo ""

        for ((i=0; i<COUNT; i++))
        do
            if [ "$i" -eq "$SELECTED" ]; then
                printf "  > %d. %s\n" \
                    "$((i + 1))" \
                    "${ITEMS[$i]}"
            else
                printf "    %d. %s\n" \
                    "$((i + 1))" \
                    "${ITEMS[$i]}"
            fi
        done

        echo ""
        echo "↑ ↓ 选择"
        echo "Enter 确认"
        echo "← 返回   → 进入"
        echo "数字键快速选择"
        echo "q 退出"
        echo ""

        KEY=$(menu_read_key)

        case "$KEY" in

            UP)
                SELECTED=$((SELECTED - 1))

                if [ "$SELECTED" -lt 0 ]; then
                    SELECTED=$((COUNT - 1))
                fi
                ;;

            DOWN)
                SELECTED=$((SELECTED + 1))

                if [ "$SELECTED" -ge "$COUNT" ]; then
                    SELECTED=0
                fi
                ;;

            ENTER|RIGHT)
                MENU_SELECTED=$((SELECTED + 1))
                return 0
                ;;

            LEFT)
                MENU_SELECTED=0
                return 0
                ;;

            QUIT)
                MENU_SELECTED=0
                return 0
                ;;

            NUMBER:*)
                NUMBER="${KEY#NUMBER:}"

                if [ "$NUMBER" -eq 0 ]; then
                    MENU_SELECTED=0
                    return 0
                fi

                if [ "$NUMBER" -ge 1 ] &&
                   [ "$NUMBER" -le "$COUNT" ]
                then
                    MENU_SELECTED="$NUMBER"
                    return 0
                fi
                ;;

        esac
    done
}

# ------------------------------------------
# 普通文字输入
#
# 支持中文 / English / 数字 / URL
# ------------------------------------------

menu_input()
{
    local PROMPT="$1"

    MENU_INPUT=""

    echo ""
    read -r -p "$PROMPT" MENU_INPUT
}

# ------------------------------------------
# 确认
# ------------------------------------------

menu_confirm()
{
    local PROMPT="$1"
    local VALUE

    echo ""
    read -r -p "$PROMPT [y/N]: " VALUE

    case "$VALUE" in
        y|Y|yes|YES|是|确定)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

# ------------------------------------------
# 等待操作完成
#
# Enter / ← / q 均可返回
# ------------------------------------------

menu_wait()
{
    echo ""
    echo "Enter 返回"
    echo "← 返回"
    echo "q 退出"
    echo ""

    while true
    do
        local KEY
        KEY=$(menu_read_key)

        case "$KEY" in
            ENTER|LEFT)
                return 0
                ;;

            QUIT)
                return 1
                ;;
        esac
    done
}
