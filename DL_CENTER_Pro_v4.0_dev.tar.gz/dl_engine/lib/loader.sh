#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Module : Module Loader
# Version: 2.1.0
# ==========================================

MODULE_PATH="$DL_MODULES"

############################################
# 加载单个模块
############################################

loader_load_file()
{
    local file="$1"

    if [ -f "$file" ]; then
        source "$file"

        if [ "$DL_DEBUG" = "1" ]; then
            echo "[DEBUG] Loaded: $file"
        fi
    fi
}

############################################
# 扫描模块目录
############################################

loader_scan()
{
    if [ ! -d "$MODULE_PATH" ]; then
        logger_error "Module directory missing"
        return 1
    fi

    while IFS= read -r module
    do
        loader_load_file "$module"
    done < <(
        find "$MODULE_PATH" \
            -type f \
            -name "*.sh" \
            ! -name "status.sh" \
            | sort
    )
}

############################################
# 初始化加载器
############################################

loader_init()
{
    loader_scan
}
