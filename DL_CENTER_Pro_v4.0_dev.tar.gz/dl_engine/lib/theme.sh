#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Module : Theme Manager
# Version: 1.0.0
# ==========================================


THEME_PATH="$DL_HOME/themes"


############################################
# 加载主题
############################################

theme_load()
{

    local theme="$1"


    if [ ! -f "$THEME_PATH/$theme.theme" ]; then

        return 1

    fi


    while IFS='=' read -r key value

    do

        [[ "$key" =~ ^# ]] && continue

        [ -z "$key" ] && continue


        export "THEME_$key=$value"


    done < "$THEME_PATH/$theme.theme"

}



############################################
# 获取主题参数
############################################

theme_get()
{

    local key="$1"

    eval echo "\$THEME_$key"

}



############################################
# 设置主题
############################################

theme_set()
{

    local theme="$1"

    dl_config_set THEME "$theme"

}



############################################
# 初始化主题
############################################

theme_init()
{

    local current

    current=$(dl_config_get THEME)


    if [ -z "$current" ]; then

        current="classic"

    fi


    theme_load "$current"

}
