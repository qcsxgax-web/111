#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Module : Startup Lifecycle
# Version: 1.0.0
# ==========================================


############################################
# 启动检查
############################################

startup_check()
{

    logger_info "Checking environment"


    if [ ! -d "$DL_HOME" ]; then

        logger_error "DL HOME missing"

        return 1

    fi


}



############################################
# 显示启动信息
############################################

startup_banner()
{

    clear


    echo "================================"
    echo "       DL CENTER Pro v4.0"
    echo "================================"


    echo

    echo "Version: $(core_version)"

    echo "Build: $(core_build)"

    echo


}



############################################
# 主启动函数
############################################

startup_run()
{

    startup_check || return 1


    startup_banner


    logger_success "System Ready"


}
