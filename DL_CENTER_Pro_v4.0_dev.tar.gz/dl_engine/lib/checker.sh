#!/data/data/com.termux/files/usr/bin/bash


check_command(){

    if command -v "$1" >/dev/null 2>&1
    then
        echo "[OK] $1"
    else
        echo "[FAIL] $1"
    fi

}



check_storage(){

    if [ -d "/sdcard/Download" ]
    then
        echo "[OK] Storage"
    else
        echo "[FAIL] Storage"
    fi

}
