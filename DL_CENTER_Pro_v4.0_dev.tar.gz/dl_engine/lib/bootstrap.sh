#!/data/data/com.t	ermux/files/usr/bin/bash
############################################
# Bootstrap Lock
############################################

if [ "$DL_BOOTSTRAPPED" = "1" ]; then
    return
fi

export DL_BOOTSTRAPPED=1


# ==========================================
# DL CENTER Pro v4.0
# Bootstrap Loader
# ==========================================

###########################################
# 加载模块
###########################################

bootstrap_load() {

    local module

    for module in \
	utils.sh \
        logger.sh \
        config.sh \
	language.sh \
	theme.sh \
        animation.sh \
        loader.sh \
	startup.sh \
        download_complete.sh
    do

        if [ -f "$DL_LIB/$module" ]; then

            source "$DL_LIB/$module"

        else

            echo "[ERROR] Missing module: $module"

            return 1

        fi

    done

}

###########################################
# 初始化
###########################################
bootstrap_init()
{

    config_load

    logger_init

    lang_init

    theme_init

    loader_init

}
###########################################
# 启动
###########################################

bootstrap() {

    bootstrap_load || return 1

    bootstrap_init || return 1

}
