#!/data/data/com.termux/files/usr/bin/bash

############################################
# DL CENTER - Download Complete Handler
############################################

download_complete()
{
    local TYPE="$1"
    local TARGET="$2"
    local FILE_LIST="$3"

    [ -z "$TYPE" ] && TYPE="Download"
    [ -z "$TARGET" ] && return 1

    local NOTIFY_TEXT=""
    local SCANNED=0
    local FAILED=0

    ########################################
    # 单文件
    ########################################

    if [ -f "$TARGET" ]; then

        case "${TARGET##*.}" in
            mp4|mkv|webm|avi|mov|m4v|mp3|m4a|flac|wav|ogg|opus|jpg|jpeg|png|gif|webp)
                if android_media_scan "$TARGET" >/dev/null 2>&1; then
                    SCANNED=1
                else
                    FAILED=1
                fi
                ;;
        esac

        NOTIFY_TEXT="$TYPE 下载完成: $(basename "$TARGET")"

    ########################################
    # 目录
    ########################################

    elif [ -d "$TARGET" ]; then

        ########################################
        # 目录媒体扫描：后台执行
        #
        # 不再让 DL CENTER 等待每个文件扫描完成
        ########################################

        (
            if [ -n "$FILE_LIST" ] && [ -f "$FILE_LIST" ]; then

                while IFS= read -r FILE
                do
                    [ -z "$FILE" ] && continue
                    [ ! -f "$FILE" ] && continue

                    case "${FILE##*.}" in
                        mp4|mkv|webm|avi|mov|m4v|mp3|m4a|flac|wav|ogg|opus|jpg|jpeg|png|gif|webp)
                            android_media_scan "$FILE" >/dev/null 2>&1
                            ;;
                    esac

                done < "$FILE_LIST"

            else

                while IFS= read -r -d '' FILE
                do
                    case "${FILE##*.}" in
                        mp4|mkv|webm|avi|mov|m4v|mp3|m4a|flac|wav|ogg|opus|jpg|jpeg|png|gif|webp)
                            android_media_scan "$FILE" >/dev/null 2>&1
                            ;;
                    esac

                done < <(
                    find "$TARGET" -type f -print0 2>/dev/null
                )

            fi
        ) >/dev/null 2>&1 &

        NOTIFY_TEXT="$TYPE 下载完成，媒体刷新已在后台进行"

    else
        logger_error "Download complete target not found: $TARGET"
        return 1
    fi

    ########################################
    # Android 通知
    ########################################

    if [ "$SCANNED" -gt 0 ]; then
        NOTIFY_TEXT="$NOTIFY_TEXT，已扫描 $SCANNED 个媒体文件"
    fi

    if [ "$FAILED" -gt 0 ]; then
        NOTIFY_TEXT="$NOTIFY_TEXT，$FAILED 个文件扫描失败"
    fi

    android_notify "DL CENTER" "$NOTIFY_TEXT" >/dev/null 2>&1

    return 0
}
