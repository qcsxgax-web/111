#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Module : Language Manager
# Version: 1.0.0
# ==========================================


LANG_PATH="$DL_HOME/language"


############################################
# 加载语言
############################################

lang_load()
{

    local lang="$1"

    if [ ! -f "$LANG_PATH/$lang.lang" ]; then

        return 1

    fi


    while IFS='=' read -r key value

    do

        [[ "$key" =~ ^# ]] && continue

        [ -z "$key" ] && continue


        export "LANG_$key=$value"


    done < "$LANG_PATH/$lang.lang"


}



############################################
# 获取文本
############################################

lang_get()
{

    local key="$1"

    eval echo "\$LANG_$key"

}



############################################
# 设置语言
############################################

lang_set()
{

    local lang="$1"


    dl_config_set LANGUAGE "$lang"


}



############################################
# 初始化语言
############################################

lang_init()
{

    local current

    current=$(dl_config_get LANGUAGE)


    if [ -z "$current" ]; then

        return 1

    fi


    lang_load "$current"

}

