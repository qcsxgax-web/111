#!/data/data/com.termux/files/usr/bin/bash


loading(){

TEXT="$1"

echo -n "$TEXT"

for i in 1 2 3
do
    echo -n "."
    sleep 0.3
done

echo

}
