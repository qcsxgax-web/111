#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Load unified menu engine
if [ -f "$DL_HOME/lib/menu.sh" ]; then
    source "$DL_HOME/lib/menu.sh"
fi

# Module : Video Downloader
# Version: 1.1.0
# ==========================================

video_is_url()
{
    local url="$1"
    [[ "$url" =~ ^https?:// ]]
}

video_info()
{
    local url="$1"

    if [ -z "$url" ]; then
        logger_error "Video URL missing"
        return 1
    fi

    if ! video_is_url "$url"; then
        logger_error "Invalid video URL"
        return 1
    fi

    echo
    echo "================================="
    echo "        Video Information"
    echo "================================="
    echo

    yt-dlp \
        --no-warnings \
        --skip-download \
        --print "Title: %(title)s" \
        --print "Uploader: %(uploader)s" \
        --print "Duration: %(duration_string)s" \
        --print "Resolution: %(resolution)s" \
        --print "Format: %(ext)s" \
        "$url"

    local RET=$?

    echo

    if [ "$RET" -ne 0 ]; then
        logger_error "Failed to retrieve video information"
        return 1
    fi

    return 0
}

video_download()
{
    local url="$1"
    local FORMAT="${2:-best}"

    if [ -z "$url" ]; then
        logger_error "Video URL missing"
        return 1
    fi

    if ! video_is_url "$url"; then
        logger_error "Invalid video URL"
        return 1
    fi

    local VIDEO_DIR
    VIDEO_DIR="${DOWNLOAD_ROOT:-$DL_DOWNLOADS}/Videos"

    mkdir -p "$VIDEO_DIR"
    mkdir -p "$DL_HOME/tmp"

    local FORMAT_OPTION

    case "$FORMAT" in
        best)
            FORMAT_OPTION="bestvideo*+bestaudio/best"
            ;;
        high)
            FORMAT_OPTION="bestvideo*+bestaudio/best"
            ;;
        720)
            FORMAT_OPTION="bestvideo*[height<=720]+bestaudio/best[height<=720]"
            ;;
        480)
            FORMAT_OPTION="bestvideo*[height<=480]+bestaudio/best[height<=480]"
            ;;
        audio)
            FORMAT_OPTION="bestaudio/best"
            ;;
        *)
            FORMAT_OPTION="bestvideo*+bestaudio/best"
            ;;
    esac

    local OUTPUT_TEMPLATE
    OUTPUT_TEMPLATE="%(title).200B.%(ext)s"

    local RESULT_FILE
    RESULT_FILE="$DL_HOME/tmp/video_result_$$.txt"

    rm -f "$RESULT_FILE"

    logger_info "Starting video download"
    logger_info "Format: $FORMAT"
    logger_info "Directory: $VIDEO_DIR"

    if [ "$FORMAT" = "audio" ]; then

        yt-dlp \
            --newline \
            -f "$FORMAT_OPTION" \
            -x \
            --audio-format mp3 \
            --output "$VIDEO_DIR/$OUTPUT_TEMPLATE" \
            --no-overwrites \
            --continue \
            --print-to-file "after_move:filepath" "$RESULT_FILE" \
            "$url"

    else

        yt-dlp \
            --newline \
            -f "$FORMAT_OPTION" \
            --merge-output-format mp4 \
            --output "$VIDEO_DIR/$OUTPUT_TEMPLATE" \
            --no-overwrites \
            --continue \
            --print-to-file "after_move:filepath" "$RESULT_FILE" \
            "$url"

    fi

    local RET=$?

    if [ "$RET" -eq 0 ]; then

        local FINAL_FILE=""
        if [ -f "$RESULT_FILE" ]; then
            FINAL_FILE=$(tail -n 1 "$RESULT_FILE")
        fi

        logger_success "Video download completed"

        echo "$(date '+%Y-%m-%d %H:%M:%S')|VIDEO|$FORMAT|$url" \
            >> "$DL_HOME/logs/history.log"

        echo
        echo "================================="
        echo "        下载完成"
        echo "================================="
        echo

        if [ -n "$FINAL_FILE" ] && [ -f "$FINAL_FILE" ]; then

            local FILE_NAME
            local FILE_SIZE

            FILE_NAME=$(basename "$FINAL_FILE")
            FILE_SIZE=$(du -h "$FINAL_FILE" 2>/dev/null | awk '{print $1}')

            echo "文件：$FILE_NAME"
            echo "大小：${FILE_SIZE:-未知}"
            echo "位置：$VIDEO_DIR"
        else
            echo "位置：$VIDEO_DIR"
        fi

        echo

        rm -f "$RESULT_FILE"

        return 0
    fi

    rm -f "$RESULT_FILE"

    logger_error "Video download failed"
    return 1
}

# ==========================================
# Video Menu
# ==========================================

video_menu()
{
    while true
    do
        menu_select "$LANG_VIDEO_MENU_TITLE" \
            "$LANG_VIDEO_DOWNLOAD" \
            "$LANG_VIDEO_720P" \
            "$LANG_VIDEO_480P" \
            "$LANG_VIDEO_HIGH" \
            "$LANG_VIDEO_AUDIO" \
            "$LANG_VIDEO_BACK"

        local CHOICE="$MENU_SELECTED"
        local FORMAT="best"

        case "$CHOICE" in
            1)
                FORMAT="best"
                ;;
            2)
                FORMAT="720"
                ;;
            3)
                FORMAT="480"
                ;;
            4)
                FORMAT="high"
                ;;
            5)
                FORMAT="audio"
                ;;
            6|0|q|Q)
                return 0
                ;;
            *)
                continue
                ;;
        esac

        clear
        echo
        printf "%s: " "$LANG_VIDEO_INPUT_URL"
        read -r VIDEO_URL

        if [ -z "$VIDEO_URL" ]; then
            logger_error "Video URL missing"
            menu_wait
            continue
        fi

        clear
        echo
        echo "================================="
        echo "        DL CENTER Pro"
        echo "================================="
        echo
        echo "正在获取视频信息，请稍候..."
        echo

        local INFO_OUTPUT=""
        local INFO_RET=0

        INFO_OUTPUT=$(
            timeout 15 yt-dlp \
                --socket-timeout 10 \
                --retries 0 \
                --no-warnings \
                --skip-download \
                --print "Title: %(title)s" \
                --print "Uploader: %(uploader)s" \
                --print "Duration: %(duration_string)s" \
                --print "Resolution: %(resolution)s" \
                --print "Format: %(ext)s" \
                "$VIDEO_URL" 2>/dev/null
        )

        INFO_RET=$?

        local INFO_TITLE
        INFO_TITLE=$(printf '%b' "$LANG_VIDEO_INFO_TITLE")

        local CONFIRM_TITLE

        if [ "$INFO_RET" -eq 124 ]; then
            logger_error "Video information request timed out"

            CONFIRM_TITLE="${INFO_TITLE}"$'\n\n'"获取视频信息超时。"$'\n'"仍然可以继续下载。"

        elif [ "$INFO_RET" -ne 0 ]; then
            logger_error "Failed to retrieve video information"

            CONFIRM_TITLE="${INFO_TITLE}"$'\n\n'"无法获取详细视频信息。"$'\n'"仍然可以继续下载。"

        else
            CONFIRM_TITLE="${INFO_TITLE}"$'\n\n'"${INFO_OUTPUT}"
        fi

        menu_select "$CONFIRM_TITLE" \
            "$LANG_VIDEO_INFO_YES" \
            "$LANG_VIDEO_INFO_NO"

        local CONFIRM="$MENU_SELECTED"

        case "$CONFIRM" in
            1)
                clear
                video_download "$VIDEO_URL" "$FORMAT"
                echo
                menu_wait
                ;;
            2|0|q|Q)
                continue
                ;;
        esac
    done
}
