#!/data/data/com.termux/files/usr/bin/bash

#########################################
# DL CENTER Pro v4.1
# Module: Main Menu
#########################################

menu_main()
{
    clear

    echo "================================="
    echo "          DL CENTER Pro"
    echo "             v4.1"
    echo "================================="
    echo

    echo "支持功能:"
    echo
    echo "  1. JMComic"
    echo "     ├─ 下载"
    echo "     ├─ 信息查询"
    echo "     └─ 预览"
    echo
    echo "  2. E-Hentai"
    echo "     └─ 即将支持"
    echo
    echo "  3. Video"
    echo "     └─ 即将支持"
    echo
    echo "  4. Direct Download"
    echo "     └─ 直链下载"
    echo
    echo "  5. Backup"
    echo "     └─ 系统备份"
    echo
    echo "  6. Language"
    echo "     └─ 语言设置"
    echo
    echo "  7. About"
    echo
    echo "  0. Exit"
    echo
    echo "---------------------------------"
    printf "请选择: "
    read MENU_CHOICE

    case "$MENU_CHOICE" in

        1)
            menu_jm
            ;;

        2)
            echo
            echo "[INFO] E-Hentai 模块即将支持"
            read -p "按 Enter 返回..."
            menu_main
            ;;

        3)
            echo
            echo "[INFO] Video 模块即将支持"
            read -p "按 Enter 返回..."
            menu_main
            ;;

        4)
            echo
            echo "[INFO] Direct Download"
            read -p "按 Enter 返回..."
            menu_main
            ;;

        5)
            dl backup
            read -p "按 Enter 返回..."
            menu_main
            ;;

        6)
            menu_language
            ;;

        7)
            menu_about
            ;;

        0)
            clear
            exit 0
            ;;

        *)
            echo
            echo "[ERROR] 无效选项"
            sleep 1
            menu_main
            ;;

    esac
}


#########################################
# JM Menu
#########################################

menu_jm()
{
    clear

    echo "================================="
    echo "          JMComic"
    echo "================================="
    echo

    echo "  1. 下载"
    echo "  2. 信息查询"
    echo "  3. 预览"
    echo "  0. 返回"
    echo

    printf "请选择: "
    read JM_CHOICE

    case "$JM_CHOICE" in

        1)
            printf "请输入 JM ID: "
            read JM_ID
            dl "$JM_ID"
            read -p "按 Enter 返回..."
            menu_jm
            ;;

        2)
            printf "请输入 JM ID: "
            read JM_ID
            dl jm info "$JM_ID"
            read -p "按 Enter 返回..."
            menu_jm
            ;;

        3)
            printf "请输入 JM ID: "
            read JM_ID
            dl jm preview "$JM_ID"
            read -p "按 Enter 返回..."
            menu_jm
            ;;

        0)
            menu_main
            ;;

        *)
            echo
            echo "[ERROR] 无效选项"
            sleep 1
            menu_jm
            ;;

    esac
}


#########################################
# Language Menu
#########################################

menu_language()
{
    clear

    echo "================================="
    echo "           Language"
    echo "================================="
    echo

    echo "  1. 中文"
    echo "  2. English"
    echo "  3. 日本語"
    echo "  0. 返回"
    echo

    printf "请选择: "
    read LANG_CHOICE

    case "$LANG_CHOICE" in

        1)
            echo "[INFO] 中文"
            ;;

        2)
            echo "[INFO] English"
            ;;

        3)
            echo "[INFO] 日本語"
            ;;

        0)
            menu_main
            return
            ;;

        *)
            echo "[ERROR] 无效选项"
            sleep 1
            ;;

    esac

    read -p "按 Enter 返回..."
    menu_main
}


#########################################
# About
#########################################

menu_about()
{
    clear

    echo "================================="
    echo "          DL CENTER Pro"
    echo "================================="
    echo
    echo "Version : 4.1"
    echo "Build   : Beta"
    echo
    echo "Modules:"
    echo "  [OK] JMComic"
    echo "  [OK] Direct Download"
    echo "  [OK] Backup"
    echo "  [--] E-Hentai"
    echo "  [--] Video"
    echo
    echo "================================="

    read -p "按 Enter 返回..."
    menu_main
}
