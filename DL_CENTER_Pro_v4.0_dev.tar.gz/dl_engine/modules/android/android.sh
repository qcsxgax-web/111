#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Module : Android Bridge
# Version: 1.0.0
# ==========================================

ANDROID_BRIDGE_VERSION="1.0.0"

############################################
# Rish Environment
############################################

android_bridge_env()
{
    export RISH_APPLICATION_ID="${RISH_APPLICATION_ID:-com.termux}"
}


############################################
# 检查 rish
############################################

android_bridge_check()
{
    if command -v rish >/dev/null 2>&1; then
        return 0
    fi

    if [ -x "$HOME/rish" ]; then
        return 0
    fi

    return 1
}

############################################
# 执行 Android 命令
############################################

android_exec()
{
    if command -v rish >/dev/null 2>&1; then
        rish "$@"
        return $?
    fi

    if [ -x "$HOME/rish" ]; then
        "$HOME/rish" "$@"
        return $?
    fi

    echo "Android Bridge: rish 不可用"
    return 1
}

############################################
# Bridge 状态
############################################

android_bridge_status()
{
    echo
    echo "=============================="
    echo "       Android Bridge"
    echo "=============================="
    echo

    echo "版本:"
    echo "$ANDROID_BRIDGE_VERSION"
    echo

    if android_bridge_check; then
        echo "rish:"
        echo "已找到"
    else
        echo "rish:"
        echo "未找到"
        echo
        echo "提示: 请先启动 Shizuku"
        return 1
    fi

    echo
    echo "Shizuku:"
    
    if android_exec -c "echo OK" >/dev/null 2>&1; then
        echo "可用"
    else
        echo "不可用"
        return 1
    fi

    echo
    echo "状态: READY"
    echo
    echo "=============================="
}

############################################
# Android 设备信息
############################################

android_device_info()
{
    echo
    echo "=============================="
    echo "       Android Device"
    echo "=============================="
    echo

    if ! android_bridge_check; then
        echo "Android Bridge 不可用"
        return 1
    fi

    echo "设备:"
    android_exec -c "getprop ro.product.manufacturer"
    android_exec -c "getprop ro.product.model"

    echo
    echo "Android:"
    android_exec -c "getprop ro.build.version.release"

    echo
    echo "SDK:"
    android_exec -c "getprop ro.build.version.sdk"

    echo
    echo "=============================="
}

############################################
# 媒体扫描
############################################

android_media_scan()
{
    local FILE="$1"

    if [ -z "$FILE" ]; then
        echo "用法: android_media_scan FILE"
        return 1
    fi

    if [ ! -f "$FILE" ]; then
        echo "文件不存在:"
        echo "$FILE"
        return 1
    fi

    local ABS_PATH
    ABS_PATH="$(realpath "$FILE" 2>/dev/null)"

    if [ -z "$ABS_PATH" ]; then
        echo "无法获取文件路径"
        return 1
    fi

    echo "媒体扫描:"
    echo "$ABS_PATH"

    android_exec -c \
        "am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d 'file://$ABS_PATH'" \
        >/dev/null 2>&1

    if [ $? -eq 0 ]; then
        echo "媒体扫描已发送"
        return 0
    fi

    echo "媒体扫描失败"
    return 1
}

############################################
# Android 通知
############################################

android_notify()
{
    local TITLE="$1"
    local TEXT="$2"

    [ -z "$TITLE" ] && TITLE="DL CENTER"
    [ -z "$TEXT" ] && TEXT="任务完成"

    if ! android_bridge_check; then
        return 1
    fi

    android_exec -c \
        "cmd notification post -S bigtext -t '$TITLE' dlcenter '$TEXT'" \
        >/dev/null 2>&1

    return $?
}

############################################
# Android Bridge 初始化
############################################

android_bridge_init()
{
    if [ "$DL_DEBUG" = "1" ]; then
        if android_bridge_check; then
            logger_success "Android Bridge available"
        else
            logger_info "Android Bridge unavailable"
        fi
    fi
}
