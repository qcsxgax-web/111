#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Detect : URL
# ==========================================


detect_url()
{

    local input="$1"


    [[ "$input" =~ ^https?:// ]]

}
