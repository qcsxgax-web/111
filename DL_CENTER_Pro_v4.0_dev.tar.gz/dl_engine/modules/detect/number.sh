#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Detect : Number ID
# ==========================================


detect_number()
{

    local input="$1"


    [[ "$input" =~ ^[0-9]+$ ]]

}
