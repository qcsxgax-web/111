#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Detect : Local File
# ==========================================


detect_file()
{

    local input="$1"


    [ -f "$input" ]

}
