#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Input Detector
# Version: 1.1.0
# ==========================================


############################################
# 输入类型检测
############################################

detect_input()
{
    local input="$1"


    ########################################
    # 空输入
    ########################################

    if [ -z "$input" ]; then

        echo "UNKNOWN"
        return 1

    fi


    ########################################
    # EHentai / ExHentai
    ########################################

    case "$input" in

        https://e-hentai.org/*|\
        http://e-hentai.org/*|\
        https://exhentai.org/*|\
        http://exhentai.org/*)

            echo "EHENTAI"
            return 0
            ;;

    esac


    ########################################
    # 普通 URL
    ########################################

    if detect_url "$input"; then

        echo "URL"

        return 0

    fi


    ########################################
    # JMComic ID
    ########################################

    if detect_number "$input"; then

        echo "NUMBER"

        return 0

    fi


    ########################################
    # 本地文件
    ########################################

    if detect_file "$input"; then

        echo "FILE"

        return 0

    fi


    ########################################
    # 未知
    ########################################

    echo "UNKNOWN"

    return 1
}
