#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Module : File Manager
# Version: 1.0.0
# ==========================================


############################################
# 文件检测
############################################

file_check()
{

    local FILE="$1"

    if [ -z "$FILE" ]; then

        logger_error "File path missing"
        return 1

    fi

    if [ ! -f "$FILE" ]; then

        logger_error "File not found: $FILE"
        return 1

    fi

    return 0

}


############################################
# 文件信息
############################################

file_info()
{

    local FILE="$1"

    file_check "$FILE" || return 1

    echo
    echo "=============================="
    echo "          File Info"
    echo "=============================="
    echo

    echo "文件:"
    echo "$FILE"

    echo
    echo "大小:"
    du -h "$FILE" | awk '{print $1}'

    echo
    echo "类型:"
    file "$FILE"

    echo
    echo "=============================="
    echo

}
