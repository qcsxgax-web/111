#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Module : Android Bridge
# Version: 1.0.0
# ==========================================

android_bridge_status()
{
    echo
    echo "========================================"
    echo "          Android Bridge"
    echo "========================================"
    echo

    # ADB
    if command -v adb >/dev/null 2>&1; then
        echo "[OK] adb"
    else
        echo "[--] adb"
    fi

    # adbon
    if command -v adbon >/dev/null 2>&1; then
        echo "[OK] adbon"
    else
        echo "[--] adbon"
    fi

    # ADB device
    if command -v adb >/dev/null 2>&1; then
        if adb get-state 2>/dev/null | grep -q "^device$"; then
            echo "[OK] ADB Device"
        else
            echo "[--] ADB Device"
        fi
    else
        echo "[--] ADB Device"
    fi

    # rish
    if command -v rish >/dev/null 2>&1; then
        echo "[OK] rish"
    elif [ -x "$HOME/rish" ]; then
        echo "[OK] rish ($HOME/rish)"
    else
        echo "[--] rish"
    fi

    echo
    echo "Shizuku:"

    if command -v rish >/dev/null 2>&1; then
        if rish -c 'echo ok' >/dev/null 2>&1; then
            echo "[OK] Shizuku"
        else
            echo "[--] Shizuku"
        fi
    elif [ -x "$HOME/rish" ]; then
        if "$HOME/rish" -c 'echo ok' >/dev/null 2>&1; then
            echo "[OK] Shizuku"
        else
            echo "[--] Shizuku"
        fi
    else
        echo "[--] Shizuku"
    fi

    echo
    echo "========================================"
}
