#!/data/data/com.termux/files/usr/bin/bash

test_module()
{

    logger_info "Test module loaded"

}
