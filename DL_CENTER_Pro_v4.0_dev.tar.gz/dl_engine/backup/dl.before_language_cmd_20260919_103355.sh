#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Command Router
# Version: 1.2.0
# ==========================================

############################################
# 环境加载
############################################

source "$HOME/dl_engine/env.sh"

############################################
# Bootstrap
############################################

unset DL_BOOTSTRAPPED

source "$DL_LIB/bootstrap.sh"

if ! bootstrap; then
    echo "Bootstrap init failed"
    exit 1
fi

############################################
# 菜单
############################################
dl_menu()
{
    while true
    do
        clear

        echo "========================================"
        echo "          $LANG_APP_NAME"
        echo "========================================"
        echo
        # Load unified menu engine
        if ! declare -F menu_select >/dev/null 2>&1; then
            source "$DL_LIB/menu.sh"
        fi

        menu_select "$LANG_MENU"             "$LANG_MENU_DIRECT"             "$LANG_MENU_VIDEO"             "JMComic 下载"             "$LANG_MENU_STATUS"             "$LANG_MENU_HISTORY"             "$LANG_MENU_BACKUP"             "$LANG_MENU_LANGUAGE"

        MENU_CHOICE="$MENU_SELECTED"

        case "$MENU_CHOICE" in

            1)
                echo
                read -p "$LANG_INPUT_URL: " URL

                if [ -n "$URL" ]; then
                    download_direct "$URL"
                fi

                echo
                read -p "$LANG_PRESS_ENTER"
                ;;


            2)
                echo
                read -p "$LANG_INPUT_VIDEO_URL: " VIDEO_URL

                if [ -n "$VIDEO_URL" ]; then
                    echo
                    echo "[$LANG_INFO] $LANG_VIDEO_NOT_READY"
                fi

                echo
                read -p "$LANG_PRESS_ENTER"
                ;;


            3)
                echo
                echo "========================================"
                echo "          JMComic 下载"
                echo "========================================"
                echo
                echo "请输入一个或多个 JMComic ID"
                echo "多个 ID 请使用空格分隔"
                echo
                read -p "JM ID: " JM_IDS

                if [ -n "$JM_IDS" ]; then

                    TOTAL=0
                    SUCCESS=0
                    FAILED=0

                    for ID in $JM_IDS
                    do
                        TOTAL=$((TOTAL + 1))

                        if [[ "$ID" =~ ^[0-9]+$ ]]; then

                            echo
                            echo "========================================"
                            echo "JM 下载 [$TOTAL]: $ID"
                            echo "========================================"

                            if jm_download "$ID"; then
                                SUCCESS=$((SUCCESS + 1))
                            else
                                FAILED=$((FAILED + 1))
                            fi

                        else

                            echo
                            echo "[ERROR] 无效 JM ID: $ID"
                            FAILED=$((FAILED + 1))

                        fi
                    done

                    echo
                    echo "========================================"
                    echo "JM 批量下载完成"
                    echo "========================================"
                    echo "总数: $TOTAL"
                    echo "成功: $SUCCESS"
                    echo "失败: $FAILED"
                    echo "========================================"

                fi

                echo
                read -p "$LANG_PRESS_ENTER"
                ;;


            4)
                echo
                "$DL_BIN/doctor"

                echo
                read -p "$LANG_PRESS_ENTER"
                ;;


            5)
                echo
                "$DL_BIN/history"

                echo
                read -p "$LANG_PRESS_ENTER"
                ;;


            6)
                echo
                "$DL_BIN/backup"

                echo
                read -p "$LANG_PRESS_ENTER"
                ;;


            7)
                while true
                do
                    clear

                    echo "========================================"
                    echo "          $LANG_MENU_LANGUAGE"
                    echo "========================================"
                    echo
                    # Unified language menu
                    menu_select "$LANG_MENU_LANGUAGE"                         "$LANG_LANGUAGE_CHINESE"                         "$LANG_LANGUAGE_ENGLISH"

                    LANG_CHOICE="$MENU_SELECTED"

                    case "$LANG_CHOICE" in

                        1)
                            lang_set "zh_CN"
                            lang_load "zh_CN"

                            echo
                            echo "$LANG_LANGUAGE_SET_SUCCESS"

                            sleep 1
                            break
                            ;;


                        2)
                            lang_set "en_US"
                            lang_load "en_US"

                            echo
                            echo "$LANG_LANGUAGE_SET_SUCCESS"

                            sleep 1
                            break
                            ;;


                        0)
                            break
                            ;;


                        *)
                            echo
                            echo "$LANG_INVALID_CHOICE"
                            sleep 1
                            ;;

                    esac

                done
                ;;


            0)
                clear
                echo
                echo "$LANG_GOODBYE"
                echo
                exit 0
                ;;


            *)
                echo
                echo "$LANG_INVALID_CHOICE"
                sleep 1
                ;;

        esac

    done
}

############################################
# 参数
############################################

COMMAND="$1"

############################################
# 无参数 → 菜单
############################################

if [ -z "$COMMAND" ]; then
    dl_menu
    exit 0
fi
############################################
# 系统命令
############################################

case "$COMMAND" in

    doctor)

        "$DL_BIN/doctor"
        exit 0
        ;;

    help|-h|--help)

        echo ""
        echo "Usage:"
        echo "  dl"
        echo "  dl <url>"
        echo "  dl doctor"
        echo "  dl version"
        echo "  dl backup"
        echo "  dl history"
        echo "  dl stats"
        echo "  dl clean"
        echo ""

        exit 0
        ;;

    version)

        "$DL_BIN/version"
        exit 0
        ;;

    update)

        "$DL_BIN/update"
        exit 0
        ;;

    backup)

        "$DL_BIN/backup"
        exit 0
        ;;

    history)

        "$DL_BIN/history" "$2"
        exit 0
        ;;

    stats)

        "$DL_BIN/stats"
        exit 0
        ;;

    clean)

        "$DL_BIN/clean"
        exit 0
        ;;

    config)

        "$DL_BIN/config" "$2" "$3" "$4"
        exit 0
        ;;
    eh)

        ACTION="$2"

        case "$ACTION" in

            status)

                ehentai_status
                exit $?
                ;;

            download)

                ehentai_download "$3"
                exit $?
                ;;
            proxy)

                if [ "$3" = "test" ]; then
                    ehentai_proxy_test
                    exit $?
                fi

                ehentai_proxy "$3"
                exit $?
                ;;
		*)

                echo
                echo "EHentai Module"
                echo
                echo "用法:"
                echo
                echo "  dl eh status"
                echo "  dl eh download URL"
                echo

                exit 1
                ;;

        esac
        ;;


    jm)


        shift



        # 无参数：显示帮助


        if [ "$#" -eq 0 ]; then


            echo


            echo "JM Module"


            echo


            echo "用法:"


            echo


            echo "  dl jm ID [ID ...]"


            echo "  dl jm info ID"


            echo "  dl jm preview ID"


            echo "  dl jm download ID [ID ...]"


            echo "  dl jm status"


            echo


            exit 1


        fi



        case "$1" in



            info)


                shift


                if [ -n "$1" ]; then


                    jm_info "$1"


                else


                    echo "用法: dl jm info ID"


                    exit 1


                fi


                ;;



            preview)


                shift


                if [ -n "$1" ]; then


                    jm_preview "$1"


                else


                    echo "用法: dl jm preview ID"


                    exit 1


                fi


                ;;



            download)


                shift



                if [ "$#" -eq 0 ]; then


                    echo "用法: dl jm download ID [ID ...]"


                    exit 1


                fi



                for ID in "$@"; do


                    if [[ "$ID" =~ ^[0-9]+$ ]]; then


                        jm_download "$ID"


                    else


                        logger_error "Invalid JM ID: $ID"


                    fi


                done


                ;;



            status)


                jm_status


                exit $?


                ;;



            *)


                # 直接输入 ID，支持多个


                for ID in "$@"; do


                    if [[ "$ID" =~ ^[0-9]+$ ]]; then


                        jm_download "$ID"


                    else


                        logger_error "Invalid JM ID: $ID"


                    fi


                done


                ;;



        esac


        ;;
    video)

        VIDEO_URL="$2"

        if [ -z "$VIDEO_URL" ]; then

            echo
            echo "=============================="
            echo "      Video Download"
            echo "=============================="
            echo

            read -p "请输入视频 URL: " VIDEO_URL

        fi

        if [ -z "$VIDEO_URL" ]; then

            logger_error "Video URL missing"
            exit 1

        fi

        video_download "$VIDEO_URL"
        exit $?

        ;;


esac




############################################
# Input Detector
############################################

TYPE=$(detect_input "$COMMAND")

logger_info "Detected type: $TYPE"

############################################
# 类型路由
############################################

case "$TYPE" in

    URL)

        download_direct "$COMMAND"
        ;;

    FILE)

    file_info "$COMMAND"
    exit $?
    ;;


    EHENTAI)

        ehentai_download "$COMMAND"
        exit $?
        ;;



    NUMBER)

        echo "Numeric input detected."
        echo "The corresponding module will be connected later."
        ;;

    UNKNOWN)

        logger_error "Unknown input: $COMMAND"

        echo
        echo "Usage:"
        echo "  dl"
        echo "  dl <url>"
        echo "  dl doctor"
        echo "  dl version"
        echo "  dl backup"
        echo "  dl history"
        echo "  dl stats"
        echo "  dl clean"
        echo "  dl config"
        ;;

esac
