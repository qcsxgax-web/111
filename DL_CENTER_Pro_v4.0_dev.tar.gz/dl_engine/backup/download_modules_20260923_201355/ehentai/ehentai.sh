#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Module : EHentai
# Version: 1.1.0
# ==========================================

EH_DOWNLOAD="/storage/emulated/0/Download/Termux/EH本子"


############################################
# EHentai 检测
############################################

ehentai_check()
{
    if ! command -v gallery-dl >/dev/null 2>&1; then
        logger_error "gallery-dl not installed"
        return 1
    fi

    return 0
}


############################################
# URL 判断
############################################

ehentai_is_url()
{
    local URL="$1"

    case "$URL" in
        https://e-hentai.org/*)
            return 0
            ;;
        http://e-hentai.org/*)
            return 0
            ;;
        https://exhentai.org/*)
            return 0
            ;;
        http://exhentai.org/*)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}


############################################
# EHentai 下载
############################################

ehentai_download()
{
    local URL="$1"

    if [ -z "$URL" ]; then
        logger_error "EHentai URL missing"
        return 1
    fi

    ehentai_check || return 1

    mkdir -p "$EH_DOWNLOAD"

    logger_info "EHentai Download Start"

    echo
    echo "=============================="
    echo "       EHentai Download"
    echo "=============================="
    echo

    echo "URL:"
    echo "$URL"

    echo
    echo "保存目录:"
    echo "$EH_DOWNLOAD"

    echo

    if [ "$AUTO_PROXY" = "true" ] || [ "$AUTO_PROXY" = "1" ]; then

    logger_info "EHentai proxy enabled"

    HTTP_PROXY="http://${PROXY_HOST}:${PROXY_PORT}" \
    HTTPS_PROXY="http://${PROXY_HOST}:${PROXY_PORT}" \
    ALL_PROXY="http://${PROXY_HOST}:${PROXY_PORT}" \
    gallery-dl \
        -d "$EH_DOWNLOAD" \
        "$URL"

else

    gallery-dl \
        -d "$EH_DOWNLOAD" \
        "$URL"

fi

    local RET=$?

    echo

    if [ "$RET" -eq 0 ]; then

        logger_success "EHentai Download Complete"

        echo "$(date '+%F %T') EHENTAI SUCCESS $URL" \
            >> "$DL_HOME/logs/history.log"

        return 0

    else

        logger_error "EHentai Download Failed"

        echo "$(date '+%F %T') EHENTAI FAILED $URL" \
            >> "$DL_HOME/logs/error.log"

        return "$RET"

    fi
}
############################################
# EHentai Status
############################################

ehentai_status()
{
    echo
    echo "=============================="
    echo "       EHentai Status"
    echo "=============================="
    echo

    if command -v gallery-dl >/dev/null 2>&1; then
        echo "gallery-dl:"
        echo "已安装"
        echo "版本: $(gallery-dl --version)"
    else
        echo "gallery-dl:"
        echo "未安装"
    fi

    echo
    echo "下载目录:"
    echo "$EH_DOWNLOAD"

    if [ -d "$EH_DOWNLOAD" ]; then
        echo "目录状态: OK"
    else
        echo "目录状态: 不存在"
    fi

    echo
    echo "Cookie 配置:"

    local COOKIE_FILE="$HOME/.config/gallery-dl/config.json"

    if [ -f "$COOKIE_FILE" ]; then
        COOKIE_STATE=$(python - "$COOKIE_FILE" <<'PY2'
import json
import sys

try:
    with open(sys.argv[1], encoding="utf-8") as f:
        d = json.load(f)

    cookies = d.get("extractor", {}).get("e-hentai", {}).get("cookies", {})
    required = ("ipb_member_id", "ipb_pass_hash", "igneous")

    print("已配置" if all(cookies.get(k) for k in required) else "不完整")

except Exception:
    print("配置错误")
PY2
)
        echo "$COOKIE_STATE"
    else
        echo "未配置"
    fi

    echo
    echo "网络模式:"
    if [ "${AUTO_PROXY:-false}" = "true" ]; then
        echo "本地代理"
        echo "${PROXY_HOST}:${PROXY_PORT}"
    else
        echo "系统 VPN"
        echo "Termux 未使用本地代理"
    fi

    echo
    echo "=============================="
}
############################################
# EHentai Proxy
############################################

ehentai_proxy()
{
    local ACTION="$1"

    case "$ACTION" in

        on)
            dl_config_set AUTO_PROXY true
            config_reload

            echo
            echo "EHentai 代理模式:"
            echo "本地代理"
            echo "${PROXY_HOST}:${PROXY_PORT}"
            echo
            echo "注意: 需要本地代理程序监听该端口。"
            ;;

        off)
            dl_config_set AUTO_PROXY false
            config_reload

            unset HTTP_PROXY
            unset HTTPS_PROXY
            unset ALL_PROXY
            unset http_proxy
            unset https_proxy
            unset all_proxy

            echo
            echo "EHentai 代理模式:"
            echo "系统 VPN"
            echo
            echo "已关闭 Termux 本地代理。"
            ;;

        *)
            echo
            echo "用法:"
            echo "  dl eh proxy on"
            echo "  dl eh proxy off"
            echo
            return 1
            ;;

    esac
}
############################################
# EHentai Proxy Test
############################################

ehentai_proxy_test()
{
    echo
    echo "=============================="
    echo "       EHentai Proxy Test"
    echo "=============================="
    echo

    echo "代理地址:"
    echo "${PROXY_HOST}:${PROXY_PORT}"
    echo

    if command -v nc >/dev/null 2>&1; then

        if nc -z -w 3 "$PROXY_HOST" "$PROXY_PORT" >/dev/null 2>&1; then
            echo "结果: ● 代理端口正常"
            return 0
        else
            echo "结果: ○ 无法连接代理端口"
            return 1
        fi

    else

        if timeout 3 bash -c \
            "</dev/tcp/$PROXY_HOST/$PROXY_PORT" \
            >/dev/null 2>&1; then

            echo "结果: ● 代理端口正常"
            return 0

        else

            echo "结果: ○ 无法连接代理端口"
            return 1

        fi

    fi
}
