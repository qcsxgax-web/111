#!/data/data/com.termux/files/usr/bin/bash

############################################
# JMComic Status
############################################

jm_status_show()
{
    local JM_DIR="/storage/emulated/0/Download/Termux/JM本子"

    local count
    local size

    count=$(find "$JM_DIR" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l)
    size=$(du -sh "$JM_DIR" 2>/dev/null | awk '{print $1}')

    [ -z "$size" ] && size="0B"

    echo
    echo "====================="
    echo " JM Status"
    echo "====================="
    echo
    echo "数量:"
    echo "$count"
    echo
    echo "大小:"
    echo "$size"
    echo
    echo "目录:"
    echo "$JM_DIR"
    echo
    echo "====================="
}
