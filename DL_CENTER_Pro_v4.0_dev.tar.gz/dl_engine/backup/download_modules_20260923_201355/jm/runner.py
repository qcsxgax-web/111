#!/data/data/com.termux/files/usr/bin/python

import sys
import os
import jmcomic


def download(album_id, save_path):

    print("[JM] Starting download:", album_id)


    option = jmcomic.JmOption.default()

    # Android / Termux：降低图片并发，避免共享存储并发写入触发 Operation not permitted
    option.download.threading.image = 30


    client = option.new_jm_client()


    album = client.get_album_detail(album_id)


    title = album.title


    # 直接使用 DL CENTER 传入的目录
    final_path = save_path


    os.makedirs(
        final_path,
        exist_ok=True
    )


    option.dir_rule.base_dir = final_path


    jmcomic.download_album(
        album_id,
        option
    )


    print("[JM] Save:")
    print(final_path)



if __name__ == "__main__":


    if len(sys.argv) < 3:

        print(
            "Usage: runner.py ID PATH"
        )

        sys.exit(1)


    album_id = sys.argv[1]

    save_path = sys.argv[2]


    download(
        album_id,
        save_path
    )
