#!/data/data/com.termux/files/usr/bin/python

import sys
import jmcomic


def preview(album_id):

    print("==============================")
    print(" JMComic Preview")
    print("==============================")
    print("ID:", album_id)

    option = jmcomic.JmOption.default()

    client = option.new_jm_client()

    album = client.get_album_detail(album_id)


    print()
    print("标题:")
    print(album.title)

    print()

    print("作者:")
    print(album.author)

    print()

    print("标签:")
    print(album.tags)

    print()

    print("页数:")
    print(album.page_count)

    print("==============================")


if __name__ == "__main__":

    if len(sys.argv) < 2:
        print("Usage: preview.py ID")
        exit(1)

    preview(sys.argv[1])
