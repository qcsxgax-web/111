#!/data/data/com.termux/files/usr/bin/bash


#########################################
# DL CENTER Pro v4.0
# Module: JMComic Downloader
#########################################


JM_HOME="$HOME/JMComic-Crawler-Python"

JM_DOWNLOAD="/storage/emulated/0/Download/Termux/JM本子"

jm_check()
{

    if [ ! -d "$JM_HOME" ]; then

        logger_error "JMComic project missing"

        return 1

    fi


    mkdir -p "$JM_DOWNLOAD"


    return 0

}


jm_download()
{

    #########################################
    # 支持一次下载多个 JM ID
    #
    # 例如：
    # dl jm 275612 470441 1433152
    #########################################

    if [ "$#" -eq 0 ]; then
        logger_error "JM ID missing"
        return 1
    fi

    local TOTAL="$#"
    local INDEX=0
    local SUCCESS=0
    local FAILED=0

    for ID in "$@"
    do

        INDEX=$((INDEX + 1))

        #########################################
        # 检查 ID
        #########################################

        if [[ ! "$ID" =~ ^[0-9]+$ ]]; then
            logger_error "Invalid JM ID: $ID"
            FAILED=$((FAILED + 1))
            continue
        fi

        jm_check || {
            FAILED=$((FAILED + 1))
            continue
        }

        logger_info "JM Download [$INDEX/$TOTAL] Start: $ID"


        #########################################
        # 获取标题和作者
        #########################################

        INFO=$(python \
        "$DL_MODULES/download/jm/cache.py" \
        "$ID")

        TITLE=$(echo "$INFO" | jq -r '.title')

        AUTHOR=$(echo "$INFO" | jq -r '.author')

        if [ -z "$TITLE" ] || [ "$TITLE" = "null" ]; then
            TITLE="$ID"
        fi

        if [ -z "$AUTHOR" ] || [ "$AUTHOR" = "null" ]; then
            AUTHOR="Unknown"
        fi


        #########################################
        # 创建专属目录
        #
        # 重要：
        # 这里继续使用 [ID]
        # 不再使用作者 + 标题
        #########################################

        FOLDER="[$ID]"

        SAVE_PATH="$JM_DOWNLOAD/$FOLDER"

        mkdir -p "$SAVE_PATH"

        logger_info "Save Path: $SAVE_PATH"


        #########################################
        # 记录下载前文件
        #########################################

        local JM_BEFORE_FILE
        local JM_AFTER_FILE
        local JM_NEW_FILE_LIST

        JM_BEFORE_FILE="$DL_HOME/tmp/jm_before_${ID}_$$.list"
        JM_AFTER_FILE="$DL_HOME/tmp/jm_after_${ID}_$$.list"
        JM_NEW_FILE_LIST="$DL_HOME/tmp/jm_new_${ID}_$$.list"

        find "$SAVE_PATH" -type f -print 2>/dev/null | sort \
            > "$JM_BEFORE_FILE"


        #########################################
        # 开始下载
        #########################################

        python \
        "$DL_MODULES/download/jm/runner.py" \
        "$ID" \
        "$SAVE_PATH"


        #########################################
        # 下载结果
        #########################################

        if [ $? -eq 0 ]; then

            SUCCESS=$((SUCCESS + 1))

            logger_success "JM Download Complete [$INDEX/$TOTAL]"


            #########################################
            # 查找本次新增文件
            #########################################

            find "$SAVE_PATH" -type f -print 2>/dev/null | sort \
                > "$JM_AFTER_FILE"

            grep -Fxv \
                -f "$JM_BEFORE_FILE" \
                "$JM_AFTER_FILE" \
                > "$JM_NEW_FILE_LIST" 2>/dev/null || true


            #########################################
            # Android 完成处理
            #########################################

            if [ -s "$JM_NEW_FILE_LIST" ]; then

                download_complete \
                    "JMComic" \
                    "$SAVE_PATH" \
                    "$JM_NEW_FILE_LIST"

            else

                logger_info \
                    "No new JM files detected for Android completion handler"

            fi


            #########################################
            # 历史记录
            #########################################

            cat >> "$DL_HOME/logs/history.log" <<EOF

--------------------------------
TIME: $(date '+%F %T')
TYPE: JMComic
ID: $ID
TITLE: $TITLE
AUTHOR: $AUTHOR
STATUS: SUCCESS
PATH: $SAVE_PATH
--------------------------------

EOF

        else

            FAILED=$((FAILED + 1))

            logger_error "JM Download Failed [$INDEX/$TOTAL]"


            #########################################
            # 历史记录
            #########################################

            cat >> "$DL_HOME/logs/history.log" <<EOF

--------------------------------
TIME: $(date '+%F %T')
TYPE: JMComic
ID: $ID
TITLE: $TITLE
AUTHOR: $AUTHOR
STATUS: FAILED
PATH: $SAVE_PATH
--------------------------------

EOF

        fi


        #########################################
        # 清理临时文件
        #########################################

        rm -f \
            "$JM_BEFORE_FILE" \
            "$JM_AFTER_FILE" \
            "$JM_NEW_FILE_LIST"


        #########################################
        # 多本下载之间稍微停一下
        #########################################

        if [ "$INDEX" -lt "$TOTAL" ]; then
            sleep 1
        fi

    done


    #########################################
    # 批量下载总结
    #########################################

    echo
    echo "========================================"
    echo "JM 批量下载完成"
    echo "========================================"
    echo "总数: $TOTAL"
    echo "成功: $SUCCESS"
    echo "失败: $FAILED"
    echo "========================================"
    echo


    #########################################
    # 只要有一个成功，整体就算成功
    #########################################

    if [ "$SUCCESS" -gt 0 ]; then
        return 0
    fi

    return 1
}

# JM 信息查询
#########################################

jm_info()
{

    ID="$1"


    if [ -z "$ID" ]; then

        logger_error "JM ID missing"

        return 1

    fi


    if [[ ! "$ID" =~ ^[0-9]+$ ]]; then

        logger_error "Invalid JM ID"

        return 1

    fi


    python \
    "$DL_MODULES/download/jm/info.py" \
    "$ID"

}
#########################################
# JM Preview
#########################################

jm_preview()
{

    ID="$1"


    if [ -z "$ID" ]; then

        logger_error "JM ID missing"

        return 1

    fi


    if [[ ! "$ID" =~ ^[0-9]+$ ]]; then

        logger_error "Invalid JM ID"

        return 1

    fi


    python \
    "$DL_MODULES/download/jm/preview.py" \
    "$ID"


    echo "$(date '+%F %T') JM PREVIEW $ID" \
    >> "$DL_HOME/logs/history.log"


    echo

    read -p "是否下载? [Y/n]: " ANSWER


    case "$ANSWER" in

        n|N)

            echo "取消下载"

        ;;


        *)

            dl "$ID"

        ;;

    esac

}
#########################################
# JM Status
#########################################

jm_status()
{
    jm_status_show
}
