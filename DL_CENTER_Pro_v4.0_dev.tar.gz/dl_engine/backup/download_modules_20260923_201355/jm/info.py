#!/data/data/com.termux/files/usr/bin/python

import sys
import jmcomic


def main():

    album_id = sys.argv[1]


    option = jmcomic.JmOption.default()


    client = option.new_jm_client()


    album = client.get_album_detail(
        album_id
    )


    print("==============================")
    print(" JMComic Information")
    print("==============================")

    print("ID:", album_id)

    print("标题:",
          album.name)

    print("作者:",
          album.author)

    print("标签:",
          album.tags)

    print("页数:",
          album.page_count)

    print("==============================")


if __name__ == "__main__":

    if len(sys.argv) < 2:
        print("请输入JM编号")
        exit(1)

    main()
