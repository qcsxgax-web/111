#!/data/data/com.termux/files/usr/bin/python

import sys
import json
import os
import jmcomic


CACHE_DIR=os.path.expanduser(
    "~/dl_engine/cache/jm"
)


def get_info(album_id):

    os.makedirs(
        CACHE_DIR,
        exist_ok=True
    )


    cache_file=os.path.join(
        CACHE_DIR,
        album_id+".json"
    )


    if os.path.exists(cache_file):

        with open(
            cache_file,
            "r",
            encoding="utf-8"
        ) as f:

            return json.load(f)



    option=jmcomic.JmOption.default()

    client=option.new_jm_client()


    album=client.get_album_detail(
        album_id
    )


    data={

        "id":album_id,

        "title":album.name,

        "author":album.author

    }


    with open(
        cache_file,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            data,
            f,
            ensure_ascii=False,
            indent=4
        )


    return data



if __name__=="__main__":


    if len(sys.argv)<2:

        exit(1)


    result=get_info(
        sys.argv[1]
    )


    print(
        json.dumps(
            result,
            ensure_ascii=False
        )
    )
