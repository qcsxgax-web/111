#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Module : Direct Downloader
# Version: 1.1.0
# ==========================================


############################################
# 判断是否支持链接
############################################

download_is_url()
{
    local input="$1"
    [[ "$input" =~ ^https?:// ]]
}


############################################
# 获取文件名
############################################

download_filename()
{
    local url="$1"
    local name="${url##*/}"

    # 去除 URL 查询参数
    name="${name%%\?*}"

    # 去除 fragment
    name="${name%%\#*}"

    # 如果无法取得文件名
    if [ -z "$name" ] || [ "$name" = "/" ]; then
        name="download"
    fi

    echo "$name"
}


############################################
# 自动判断下载目录
############################################

download_category()
{
    local filename="$1"
    local ext="${filename##*.}"

    ext="${ext,,}"

    case "$ext" in

        mp4|mkv|webm|mov|avi|flv|m4v|mpeg|mpg|3gp)
            echo "Videos"
            ;;

        mp3|flac|wav|m4a|aac|ogg|opus|wma)
            echo "Music"
            ;;

        jpg|jpeg|png|gif|webp|bmp|svg|ico|tif|tiff)
            echo "Images"
            ;;

        zip|rar|7z|tar|gz|bz2|xz|zst)
            echo "Archive"
            ;;

        pdf|txt|doc|docx|xls|xlsx|ppt|pptx|csv|epub)
            echo "Documents"
            ;;

        *)
            echo "Others"
            ;;

    esac
}


############################################
# 下载函数
############################################

download_direct()
{
    local url="$1"

    if ! download_is_url "$url"; then
        logger_error "Invalid URL"
        return 1
    fi


    local filename
    filename=$(download_filename "$url")


    local CATEGORY
    CATEGORY=$(download_category "$filename")


    local DOWNLOAD_DIR
    DOWNLOAD_DIR="$DL_DOWNLOADS/$CATEGORY"


    logger_info "Starting download: $filename"
    logger_info "Category: $CATEGORY"


    mkdir -p "$DOWNLOAD_DIR"


    ########################################
    # 记录下载前已有文件
    ########################################

    local BEFORE_FILE
    BEFORE_FILE="$DL_HOME/tmp/direct_before_$$.list"

    find "$DOWNLOAD_DIR" -type f -print 2>/dev/null |
        sort > "$BEFORE_FILE"


    ########################################
    # aria2 多连接下载
    ########################################

    aria2c \
        -x "$THREAD" \
        -s "$THREAD" \
        -d "$DOWNLOAD_DIR" \
        "$url"


    local RET=$?


    ########################################
    # 下载成功
    ########################################

    if [ "$RET" -eq 0 ]; then

        logger_success "Download completed: $filename"


        echo "$(date '+%Y-%m-%d %H:%M:%S')|$url" \
            >> "$DL_HOME/logs/history.log"


        ####################################
        # 找出本次新增文件
        ####################################

        local NEW_FILE

        NEW_FILE=$(
            find "$DOWNLOAD_DIR" -type f -print 2>/dev/null |
            sort |
            grep -Fxv -f "$BEFORE_FILE" |
            head -n 1
        )


        rm -f "$BEFORE_FILE"


        ####################################
        # Android 完成处理
        ####################################

        if [ -n "$NEW_FILE" ]; then

            download_complete \
                "Direct Download" \
                "$NEW_FILE"

        else

            logger_info \
                "No new file detected for Android completion handler"

        fi


        return 0


    else

        rm -f "$BEFORE_FILE"

        logger_error "Download failed"

        return 1

    fi
}
