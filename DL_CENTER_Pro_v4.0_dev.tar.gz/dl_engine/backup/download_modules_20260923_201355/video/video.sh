#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Module : Video Downloader
# Version: 1.0.0
# ==========================================

############################################
# 检查 yt-dlp
############################################

video_check()
{
    if ! command -v yt-dlp >/dev/null 2>&1; then

        logger_error "yt-dlp not installed"

        echo
        echo "请先安装 yt-dlp:"
        echo "pkg install yt-dlp"

        return 1
    fi

    return 0
}

############################################
# 视频下载
############################################

video_download()
{
    local URL="$1"

    if [ -z "$URL" ]; then

        logger_error "Video URL missing"

        return 1
    fi

    video_check || return 1

    mkdir -p "$DOWNLOAD_ROOT/Videos"

    logger_info "Video Download Start"

    echo
    echo "Video URL:"
    echo "$URL"
    echo
    echo "保存目录:"
    echo "$DOWNLOAD_ROOT/Videos"
    echo

    yt-dlp \
        --newline \
        -P "$DOWNLOAD_ROOT/Videos" \
        "$URL"

    local RET=$?

    echo

    if [ "$RET" -eq 0 ]; then

        logger_success "Video Download Complete"

        echo "$(date '+%F %T') VIDEO SUCCESS $URL" \
            >> "$DL_HOME/logs/history.log"

        # 查找本次下载产生的视频文件
        local VIDEO_FILE
        VIDEO_FILE=$(
            find "$DOWNLOAD_ROOT/Videos" -type f \
                \( -iname "*.mp4" -o -iname "*.mkv" -o -iname "*.webm" \
                -o -iname "*.avi" -o -iname "*.mov" -o -iname "*.m4v" \) \
                -printf '%T@ %p\n' 2>/dev/null |
            sort -nr |
            head -n 1 |
            cut -d' ' -f2-
        )

        if [ -n "$VIDEO_FILE" ] && [ -f "$VIDEO_FILE" ]; then
            download_complete "Video Download" "$VIDEO_FILE"
        else
            logger_info "Video file not detected for Android completion handler"
        fi

        return 0

    else

        logger_error "Video Download Failed"

        echo "$(date '+%F %T') VIDEO FAILED $URL" \
            >> "$DL_HOME/logs/error.log"

        return "$RET"

    fi
}
