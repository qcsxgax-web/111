#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Command: Config
# ==========================================

CONFIG_FILE="$DL_CONFIG/config.conf"

if [ -f "$DL_HOME/lib/config.sh" ]; then
    source "$DL_HOME/lib/config.sh"
else
    echo "[ERROR] config.sh not found."
    exit 1
fi

show_help()
{
    echo ""
    echo "================================="
    echo "        DL CENTER Config"
    echo "================================="
    echo ""
    echo "Usage:"
    echo "  dl config"
    echo "  dl config show"
    echo "  dl config get <KEY>"
    echo "  dl config set <KEY> <VALUE>"
    echo "  dl config remove <KEY>"
    echo "  dl config reload"
    echo ""
}

case "$1" in

    "")
        show_help
        ;;

    show)
        echo ""
        echo "================================="
        echo "        Current Config"
        echo "================================="
        echo ""

        config_list

        echo ""
        ;;

    get)
        if [ -z "$2" ]; then
            echo "[ERROR] Missing config key."
            echo "Usage: dl config get <KEY>"
            exit 1
        fi

        config_load

        echo ""
        echo "$2=$(dl_config_get "$2")"
        echo ""
        ;;

    set)
        if [ -z "$2" ] || [ -z "$3" ]; then
            echo "[ERROR] Missing key or value."
            echo "Usage: dl config set <KEY> <VALUE>"
            exit 1
        fi

        dl_config_set "$2" "$3"
        config_reload

        echo ""
        echo "[OK] $2=$3"
        echo ""
        ;;

    remove)
        if [ -z "$2" ]; then
            echo "[ERROR] Missing config key."
            echo "Usage: dl config remove <KEY>"
            exit 1
        fi

        dl_config_remove "$2"

        echo ""
        echo "[OK] Removed: $2"
        echo ""
        ;;

    reload)
        config_reload

        echo ""
        echo "[OK] Configuration reloaded."
        echo ""
        ;;

    help|-h|--help)
        show_help
        ;;

    *)
        echo ""
        echo "[ERROR] Unknown config option: $1"
        show_help
        exit 1
        ;;

esac
