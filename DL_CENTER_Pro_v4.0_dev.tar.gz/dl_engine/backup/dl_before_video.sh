#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Command Router
# Version: 1.2.0
# ==========================================

############################################
# 环境加载
############################################

source "$HOME/dl_engine/env.sh"

############################################
# Bootstrap
############################################

unset DL_BOOTSTRAPPED

source "$DL_LIB/bootstrap.sh"

if ! bootstrap; then
    echo "Bootstrap init failed"
    exit 1
fi

############################################
# 菜单
############################################
dl_menu()
{
    while true
    do

        clear

        echo "========================================"
        echo "          $LANG_APP_NAME"
        echo "========================================"
        echo
        echo "  1. $LANG_MENU_DIRECT"
        echo "  2. $LANG_MENU_VIDEO"
        echo "  3. $LANG_MENU_STATUS"
        echo "  4. $LANG_MENU_HISTORY"
        echo "  5. $LANG_MENU_BACKUP"
        echo "  6. $LANG_MENU_LANGUAGE"
        echo "  0. $LANG_EXIT"
        echo
        echo "----------------------------------------"
        echo " $LANG_MENU_SUPPORTED:"
        echo "  • $LANG_SUPPORTED_URL"
        echo "  • $LANG_SUPPORTED_VIDEO"
        echo "  • $LANG_SUPPORTED_JM"
        echo "  • $LANG_SUPPORTED_EHENTAI"
        echo "  • $LANG_SUPPORTED_FILE"
        echo "----------------------------------------"
        echo

        read -p " $LANG_INPUT_SELECT: " MENU_CHOICE

        case "$MENU_CHOICE" in

            1)
                echo
                read -p "$LANG_INPUT_URL: " URL

                if [ -n "$URL" ]; then
                    download_direct "$URL"
                fi

                echo
                read -p "$LANG_PRESS_ENTER"
                ;;


            2)
                echo
                read -p "$LANG_INPUT_VIDEO_URL: " VIDEO_URL

                if [ -n "$VIDEO_URL" ]; then
                    echo
                    echo "[$LANG_INFO] $LANG_VIDEO_NOT_READY"
                fi

                echo
                read -p "$LANG_PRESS_ENTER"
                ;;


            3)
                echo
                "$DL_BIN/doctor"

                echo
                read -p "$LANG_PRESS_ENTER"
                ;;


            4)
                echo
                "$DL_BIN/history"

                echo
                read -p "$LANG_PRESS_ENTER"
                ;;


            5)
                echo
                "$DL_BIN/backup"

                echo
                read -p "$LANG_PRESS_ENTER"
                ;;


            6)

                while true
                do

                    clear

                    echo "========================================"
                    echo "          $LANG_MENU_LANGUAGE"
                    echo "========================================"
                    echo
                    echo "  1. $LANG_LANGUAGE_CHINESE"
                    echo "  2. $LANG_LANGUAGE_ENGLISH"
                    echo "  0. $LANG_EXIT"
                    echo

                    read -p "$LANG_INPUT_SELECT: " LANG_CHOICE

                    case "$LANG_CHOICE" in

                        1)
                            lang_set "zh_CN"
                            lang_load "zh_CN"

                            echo
                            echo "$LANG_LANGUAGE_SET_SUCCESS"

                            sleep 1
                            break
                            ;;


                        2)
                            lang_set "en_US"
                            lang_load "en_US"

                            echo
                            echo "$LANG_LANGUAGE_SET_SUCCESS"

                            sleep 1
                            break
                            ;;


                        0)
                            break
                            ;;


                        *)
                            echo
                            echo "$LANG_INVALID_CHOICE"
                            sleep 1
                            ;;

                    esac

                done
                ;;


            0)
                clear
                echo
                echo "$LANG_GOODBYE"
                echo
                exit 0
                ;;


            *)
                echo
                echo "$LANG_INVALID_CHOICE"
                sleep 1
                ;;

        esac

    done
}









############################################
# 参数
############################################

COMMAND="$1"

############################################
# 无参数 → 菜单
############################################

if [ -z "$COMMAND" ]; then
    dl_menu
    exit 0
fi

############################################
# 系统命令
############################################

case "$COMMAND" in

    doctor)

        "$DL_BIN/doctor"
        exit 0
        ;;

    version)

        "$DL_BIN/version"
        exit 0
        ;;

    update)

        "$DL_BIN/update"
        exit 0
        ;;

    backup)

        "$DL_BIN/backup"
        exit 0
        ;;

    history)

        "$DL_BIN/history"
        exit 0
        ;;

esac

############################################
# Input Detector
############################################

TYPE=$(detect_input "$COMMAND")

logger_info "Detected type: $TYPE"

############################################
# 类型路由
############################################

case "$TYPE" in

    URL)

        download_direct "$COMMAND"
        ;;

    FILE)

        echo "Local file detected"
        ;;

    EHENTAI)

        echo "This input type is not configured."
        ;;

    NUMBER)

        echo "Numeric input detected."
        echo "The corresponding module will be connected later."
        ;;

    UNKNOWN)

        logger_error "Unknown input: $COMMAND"

        echo
        echo "Usage:"
        echo "  dl"
        echo "  dl <url>"
        echo "  dl doctor"
        echo "  dl version"
        echo "  dl backup"
        echo "  dl history"
        ;;

esac
