#!/data/data/com.termux/files/usr/bin/bash

# ==========================================
# DL CENTER Pro v4.0
# Command Router
# Version: 1.2.0
# ==========================================

############################################
# 环境加载
############################################

source "$HOME/dl_engine/env.sh"

############################################
# Bootstrap
############################################

unset DL_BOOTSTRAPPED

source "$DL_LIB/bootstrap.sh"

if ! bootstrap; then
    echo "Bootstrap init failed"
    exit 1
fi

############################################
# 菜单
############################################
dl_menu()
{
    while true
    do

        clear

        echo "========================================"
        echo "          DL CENTER Pro v4.0"
        echo "========================================"
        echo
        echo "  1. Direct Download"
        echo "  2. Video Download"
        echo "  3. System Status"
        echo "  4. History"
        echo "  5. Backup"
        echo "  6. Language"
        echo "  0. Exit"
        echo
        echo "----------------------------------------"
        echo " Supported:"
        echo "  • Direct URL"
        echo "  • Video"
        echo "  • JMComic ID"
        echo "  • EHentai URL"
        echo "  • Local File"
        echo "----------------------------------------"
        echo

        read -p " Select: " MENU_CHOICE

        case "$MENU_CHOICE" in

            1)
                echo
                read -p "URL: " URL

                if [ -n "$URL" ]; then
                    download_direct "$URL"
                fi

                echo
                read -p "Press Enter to continue..."
                ;;


            2)
                echo
                read -p "Video URL: " VIDEO_URL

                if [ -n "$VIDEO_URL" ]; then
                    echo
                    echo "[INFO] Video module will be connected later."
                    echo "URL: $VIDEO_URL"
                fi

                echo
                read -p "Press Enter to continue..."
                ;;


            3)
                echo
                "$DL_BIN/doctor"

                echo
                read -p "Press Enter to continue..."
                ;;


            4)
                echo
                "$DL_BIN/history"

                echo
                read -p "Press Enter to continue..."
                ;;


            5)
                echo
                "$DL_BIN/backup"

                echo
                read -p "Press Enter to continue..."
                ;;


            6)

                while true
                do

                    clear

                    echo "========================================"
                    echo "          Language / 语言"
                    echo "========================================"
                    echo
                    echo "  1. 中文"
                    echo "  2. English"
                    echo "  0. Back"
                    echo

                    read -p " Select: " LANG_CHOICE

                    case "$LANG_CHOICE" in

                        1)
                            lang_set "zh_CN"
                            lang_load "zh_CN"

                            echo
                            echo "$LANG_LANGUAGE_SET_SUCCESS"

                            sleep 1
                            break
                            ;;


                        2)
                            lang_set "en_US"
                            lang_load "en_US"

                            echo
                            echo "$LANG_LANGUAGE_SET_SUCCESS"

                            sleep 1
                            break
                            ;;


                        0)
                            break
                            ;;


                        *)
                            echo
                            echo "Invalid choice."
                            sleep 1
                            ;;

                    esac

                done
                ;;


            0)
                clear
                echo
                echo "Goodbye!"
                echo
                exit 0
                ;;


            *)
                echo
                echo "Invalid choice."
                sleep 1
                ;;

        esac

    done
}










############################################
# 参数
############################################

COMMAND="$1"

############################################
# 无参数 → 菜单
############################################

if [ -z "$COMMAND" ]; then
    dl_menu
    exit 0
fi

############################################
# 系统命令
############################################

case "$COMMAND" in

    doctor)

        "$DL_BIN/doctor"
        exit 0
        ;;

    version)

        "$DL_BIN/version"
        exit 0
        ;;

    update)

        "$DL_BIN/update"
        exit 0
        ;;

    backup)

        "$DL_BIN/backup"
        exit 0
        ;;

    history)

        "$DL_BIN/history"
        exit 0
        ;;

esac

############################################
# Input Detector
############################################

TYPE=$(detect_input "$COMMAND")

logger_info "Detected type: $TYPE"

############################################
# 类型路由
############################################

case "$TYPE" in

    URL)

        download_direct "$COMMAND"
        ;;

    FILE)

        echo "Local file detected"
        ;;

    EHENTAI)

        echo "This input type is not configured."
        ;;

    NUMBER)

        echo "Numeric input detected."
        echo "The corresponding module will be connected later."
        ;;

    UNKNOWN)

        logger_error "Unknown input: $COMMAND"

        echo
        echo "Usage:"
        echo "  dl"
        echo "  dl <url>"
        echo "  dl doctor"
        echo "  dl version"
        echo "  dl backup"
        echo "  dl history"
        ;;

esac
