#!/data/data/com.termux/files/usr/bin/bash


########################################
# DL CENTER Pro v4.0
# JMComic Module
# Version: 1.0.0
########################################


jmcomic_download()
{

local album_id="$1"


if [ -z "$album_id" ]; then

    logger_error "JMComic ID missing"
    return 1

fi


logger_info "Starting JMComic download: $album_id"



JM_PATH="$DL_DOWNLOADS/Images/JMComic"


mkdir -p "$JM_PATH"



python - <<EOF

import jmcomic

option = jmcomic.create_option_by_file(
    "$DL_CONFIG/jmcomic/config.yml"
)

jmcomic.download_album(
    "$album_id",
    option
)

EOF



if [ $? -eq 0 ]; then

    logger_success "JMComic download completed"

    echo "$(date '+%F %T') JM $album_id SUCCESS" \
    >> "$DL_HOME/logs/history.log"

else

    logger_error "JMComic download failed"

    echo "$(date '+%F %T') JM $album_id FAILED" \
    >> "$DL_HOME/logs/error.log"

fi


}
