#!/data/data/com.termux/files/usr/bin/bash


echo "DL CENTER Pro v4.0"

echo

read -p "Remove DL CENTER? (yes/no): " ANSWER


if [ "$ANSWER" = "yes" ]
then

rm -rf ~/dl_engine

sed -i '/DL CENTER Pro v4.0/d' ~/.bashrc


echo "Removed"

else

echo "Cancelled"

fi
