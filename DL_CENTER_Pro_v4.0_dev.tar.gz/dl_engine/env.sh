#!/data/data/com.termux/files/usr/bin/bash

export DL_HOME="$HOME/dl_engine"

export DL_BIN="$DL_HOME/bin"
export DL_LIB="$DL_HOME/lib"
export DL_CONFIG="$DL_HOME/config"
export DL_MODULES="$DL_HOME/modules"
export DL_DOWNLOADS="$DL_HOME/downloads"
export DL_LANGUAGE="$DL_HOME/language"
export DL_THEME="$DL_HOME/themes"
export DL_LOG="$DL_HOME/logs"
export DL_DEBUG=0

export PATH="$DL_BIN:$PATH"

if [ -f "$DL_LIB/completion.sh" ]; then
    source "$DL_LIB/completion.sh"
fi
